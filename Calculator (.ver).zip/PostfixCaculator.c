#include "ListBasedStack.h"
#include <string.h>
#include <ctype.h>
#include <math.h>

int start = 0, cur = 0, cnt = 0, jumcnt = 0, totaljumcnt = 0;
double temp = 0;

void jinusint(Stack* stack, char* exp, int end)
{
    char token;
    int i;

    for(i=start; i<end; i++)
    {
        token = exp[i];
        temp*=10;
        temp+=token-'0';
    }
    token = exp[i]-17;
    temp*=10;
    temp+=token-'0';
    if(exp[end+1] != '.')
    {
        start=end+1;
        SPush(stack, temp);
        temp = 0;
    }
}

void jinusdouble(Stack* stack, char* exp, int end)
{
    char token;
    int i, dobcnt = 1;

    for(i=cur+1; i<end; i++)
    {
        token = exp[i];
        temp += (token-'0') / pow(10, dobcnt);
        dobcnt++;
    }
    token = exp[i]-49;
    temp+=(token-'0')/pow(10, dobcnt);

    SPush(stack, temp);
    temp = 0;
    cnt = 0;
    dobcnt = 1;
    jumcnt = 0;
    start = end + 1;
}

double PostfixCaculator(char exp[])
{
    Stack stack;
    int i;
    int n;
    double n1, n2;
    char token;

    StackInit(&stack);
    for(i=0; i<strlen(exp); i++)
    {
        token = exp[i];
        if(isupper(token))
            jinusint(&stack, exp, i);

        else if(token == '.')
        {
            cur=i;
            jumcnt++;
            totaljumcnt++;
        }

        else if(islower(token))
            jinusdouble(&stack, exp, i);

        else if(isdigit(token))
            n++;

        else
        {
            start++;
            n2 = SPop(&stack);
            n1 = SPop(&stack);

            switch(token)
            {
                case '+':
                    SPush(&stack, n1+n2);
                    break;
                case '-':
                    SPush(&stack, n1-n2);
                    break;
                case '*':
                    SPush(&stack, n1*n2);
                    break;
                case '/':
                    SPush(&stack, n1/n2);
                    totaljumcnt++;
                    break;

            }
        }
    }
    start = 0;
    return SPop(&stack);
}
