#include "InfixToPostfix.h"
#include "ListBasedStack.h"
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>

int getOperatorPriority(char op)
{
    switch(op)
    {
        case '*': case'/':
            return 5;

        case '+': case '-':
            return 3;

        case '(':
            return 1;
    }
}

int IsFirstOrEqual(char op1, char op2)
{
    int pri1 = getOperatorPriority(op1);
    int pri2 = getOperatorPriority(op2);

    return pri1 >= pri2;
}

void convertToPostfix(char exp[])
{
    Stack stack;
    int len = strlen(exp), cntopen = 0, cntclose = 0, j, countop = 0, open = 0;
    char* postfix = (char*)malloc(sizeof(char)*(len+1));

    int i, cur = 0, cnt = 0;
    char token, tokencpy;

    StackInit(&stack);
    memset(postfix, 0, len+1);

    for(i=0;  i<len; i++)
    {
        token = exp[i];
        if(isdigit(token))
            postfix[cur++] = token;

        else if(token == '.')
        {
            postfix[cur-1]+=17;
            cnt++;
            postfix[cur++] = token;
        }

        else
        {
            switch(token)
            {
                case '(':
                    cntopen++;
                    countop = 0;
                    open++;
                    SPush(&stack, token);
                    break;

                case '+': case '-': case '*': case '/':
                    if(cnt == 0 && exp[i-1] != ')')
                    {
                        if(countop == 0)
                        {
                            postfix[cur-1]+=17;
                        }

                        else
                        {
                            postfix[cur-1-countop]+=17;
                            countop--;
                        }
                    }

                    else if(exp[i-1] != ')')
                    {
                        postfix[cur-1]+=49;
                        cnt = 0;
                    }

                    while(!SIsEmpty(&stack) && IsFirstOrEqual(SPeek(&stack), token))
                    {
                        postfix[cur++] = SPop(&stack);
                    }
                    SPush(&stack, token);
                    break;

                case ')':
                    while(SPeek(&stack)!='(')
                    {
                    if(cnt == 0 && exp[i-1] != ')')
                    {
                        if(countop == 0)
                        {
                            postfix[cur-1]+=17;
                        }

                        else
                        {
                            postfix[cur-1-countop]+=17;
                            countop--;
                        }
                    }

                    else if(exp[i-1] != ')')
                    {
                        postfix[cur-1]+=49;
                        cnt = 0;
                    }
                        countop++;
                        postfix[cur++] = SPop(&stack);
                    }
                    SPop(&stack);
                    break;
            }
        }
    }

    if(cnt == 0)
    {
        postfix[cur-1]+=17;
    }

    else
    {
        postfix[cur-1]+=49;
        cnt = 0;
    }

    while(!SIsEmpty(&stack))
        postfix[cur++] = SPop(&stack);

    strcpy(exp, postfix);
    free(postfix);
}
