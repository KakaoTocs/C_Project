#include "ListBasedStack.h"
#include <stdio.h>
#include <stdlib.h>

void StackInit(Stack* pstack)
{
    pstack->head = NULL;
}

int SIsEmpty(Stack* pstack)
{
    if(pstack->head == NULL)
        return TRUE;
    else
        return FALSE;
}

void SPush(Stack* pstack, Data data)
{
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;

    newNode->next = pstack->head;
    pstack->head=newNode;
}

Data SPop(Stack* pstack)
{
    Node* rnode;
    Data rdata;

    if(SIsEmpty(pstack))
    {
        printf("Stack is empty.\n");
        exit(-1);
    }

    rnode = pstack->head;
    rdata = rnode->data;

    pstack->head = pstack->head->next; /// pstack->head->next == rnode->next
    free(rnode);

    return rdata;
}

Data SPeek(Stack* pstack)
{
    if(SIsEmpty(pstack))
    {
        printf("Stack is empty.\n");
        exit(-1);
    }
    return pstack->head->data;

}
