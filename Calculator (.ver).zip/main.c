#include <stdio.h>
#include <stdlib.h>
#include "PostfixCaculator.h"
#include "InfixToPostfix.h"

int main()
{
    int incount = 0;
    char exp[100];
    double result;

    printf("���� �Է�(����:q) : ");
    scanf("%s", exp);

    while(exp[0] != 'q')
    {

        convertToPostfix(exp);
        printf("%s\n", exp);

        result = PostfixCaculator(exp);

        printf("%g\n", result);

        totaljumcnt = 0;
        printf("���� �Է�(����:q) : ");
        scanf("%s", exp);
    }

    return 0;
}
