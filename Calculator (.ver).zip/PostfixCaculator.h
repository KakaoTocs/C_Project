#ifndef POSTFIXCACULATOR_H_INCLUDED
#define POSTFIXCACULATOR_H_INCLUDED

double totaljumcnt;
double PostfixCaculator(char exp[]);

#endif // POSTFIXCACULATOR_H_INCLUDED
